if("undefined"===typeof $||$.hasOwnProperty("fn")&&$.fn.hasOwnProperty("jquery")&&parent.MP.Utils.version_compare($.fn.jquery,jQuery.fn.jquery,"<"))var $=jQuery.noConflict();
